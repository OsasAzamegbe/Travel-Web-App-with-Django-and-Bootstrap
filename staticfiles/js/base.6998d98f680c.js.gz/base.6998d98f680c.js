const themeSlider = document.querySelector('.slider');
themeSlider.addEventListener('click', () => {
    
    document.body.classList.toggle('dark');
});